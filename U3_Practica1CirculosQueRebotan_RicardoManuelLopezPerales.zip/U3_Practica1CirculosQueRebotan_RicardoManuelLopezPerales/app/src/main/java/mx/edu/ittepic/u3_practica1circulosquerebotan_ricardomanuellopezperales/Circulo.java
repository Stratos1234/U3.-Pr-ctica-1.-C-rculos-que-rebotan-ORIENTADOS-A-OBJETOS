package mx.edu.ittepic.u3_practica1circulosquerebotan_ricardomanuellopezperales;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.CountDownTimer;

public class Circulo {
    float x, y;
    int  desplazamientox0 , desplazamientoy0  ;
    CountDownTimer timer;
    int color;
    int tamano;

    public Circulo(int posx, int posy, final Lienzo l, int c , int t) {
        x = posx;
        y = posy;

        color = c;
        tamano=t;


        timer = new CountDownTimer(1000, 1) {
            @Override
            public void onTick(long millisUntilFinished) {
                x += desplazamientox0;
                y += desplazamientoy0;


                if (x >= l.getWidth() - 90) // parte de la derecha de la pantalla
                {
                    desplazamientox0 *= -1;

                }
                if (x <= 60) //parte de la izquierda de la pantalla
                {
                    desplazamientox0 *= -1;
                }

                if (y >= l.getHeight() - 80) //getHight y getwitch parte de abajo  de la pantalla
                {
                    desplazamientoy0 *= -1;
                }

                if (y <= 80) // parte de arriba de la pantalla
                {
                    desplazamientoy0 *= -1;
                }

                l.invalidate();


            }

            @Override
            public void onFinish() {

                start();
            }
        };
    }

    public void pintar(Canvas c, Paint p) {
        p.setColor(color);

        c.drawCircle(x, y, tamano, p);


    }

    public void movemiento(int incrementax, int incrementay) {
     desplazamientox0=incrementax;
     desplazamientoy0=incrementay;
        timer.start();
    }

}


