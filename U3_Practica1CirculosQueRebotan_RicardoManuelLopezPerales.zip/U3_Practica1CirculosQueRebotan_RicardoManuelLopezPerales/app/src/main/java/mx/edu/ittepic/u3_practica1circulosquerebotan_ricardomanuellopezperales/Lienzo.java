package mx.edu.ittepic.u3_practica1circulosquerebotan_ricardomanuellopezperales;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class Lienzo extends View {
    Circulo n1, n2, n3, n4,n5;


    public Lienzo(Context context) {
        super(context);
        n1 = new Circulo(300, 500, this,Color.WHITE,130);
        n2 = new Circulo(250, 100, this,Color.RED,100);
        n3 = new Circulo(350, 400, this,Color.GRAY,90);
        n4 = new Circulo(150, 200, this,Color.GREEN,110);
        n5 = new Circulo(700, 600, this,Color.DKGRAY,120);

        n1.movemiento(10,10);
        n2.movemiento(20,20);
        n3.movemiento(40,40);
        n4.movemiento(5,5);
        n5.movemiento(15,15);



    }

    @Override
    public void onDraw(Canvas canvas) {

        Paint p = new Paint();
        canvas.drawColor(Color.CYAN);
        n1.pintar(canvas, p);
        n2.pintar(canvas, p);
        n3.pintar(canvas, p);
        n4.pintar(canvas, p);
        n5.pintar(canvas, p);

    }
}
